
package com.mycompany.awn3;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;




public class PeerEducationTutor extends javax.swing.JFrame {

    /**
     * Creates new form PeerEducationTutor
     */
    public PeerEducationTutor() {
        initComponents();
        
        Populate_table ();
    }


    
    
    
        public static Connection getConnection() throws ClassNotFoundException
            
            //CommunityPartnerShip() Class = new CommunityPartnerShip();
    {
        Connection con = null;
        
         try {

            //Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "Nn123456!!");
        } catch (SQLException ex) {

             System.out.println(ex.getMessage());

        }
        return con;
    }

    
    
      
    private void Populate_table () {
    
    
    
     try {


            //Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "Nn123456!!");
           //to display
           String sqlquery   = " SELECT Session_No ,Tutor_Name , Course_ID , Course_Name , ChoosenDay , ChoosenTime FROM peer_education ";
           PreparedStatement pst = con.prepareStatement(sqlquery);
           ResultSet rs = pst.executeQuery();
           
           jTable1.setModel( DbUtils.resultSetToTableModel(rs) );
   
            
        } catch (SQLException ex) {

             System.out.println(ex.getMessage());

        }
     
    
    }

    

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Course_ID_jLabel = new javax.swing.JLabel();
        Session_TextField = new javax.swing.JTextField();
        CoursNamee_TextField = new javax.swing.JTextField();
        Course_Name_Label = new javax.swing.JLabel();
        Tutor_Name_jLabel3 = new javax.swing.JLabel();
        ttttime_TextField = new javax.swing.JTextField();
        Day_Label = new javax.swing.JLabel();
        Time_Label = new javax.swing.JLabel();
        Date_TextField = new javax.swing.JTextField();
        CID_TextField = new javax.swing.JTextField();
        AddButton1 = new javax.swing.JButton();
        DeleteButton2 = new javax.swing.JButton();
        Session_No_jLabel = new javax.swing.JLabel();
        ChoosenTim_jTextField = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        BackButton6 = new javax.swing.JButton();
        EXITButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setBackground(new java.awt.Color(46, 62, 93));
        jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jTable1.setFont(new java.awt.Font("Lucida Fax", 1, 16)); // NOI18N
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Session No", "Tutor Name", "Course ID", "Course Name", "Day", "Time"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setAlignmentX(5.0F);
        jTable1.setAlignmentY(5.0F);
        jTable1.setPreferredSize(new java.awt.Dimension(2000, 2000));
        jTable1.setRowHeight(40);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 100, 1030, 460));

        Course_ID_jLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Course_ID_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        Course_ID_jLabel.setText("Course ID :");
        getContentPane().add(Course_ID_jLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 190, 40));

        Session_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Session_TextField.setToolTipText("Enter Sesstion Number");
        Session_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Session_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(Session_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 139, -1));

        CoursNamee_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(CoursNamee_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, 139, -1));

        Course_Name_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Course_Name_Label.setForeground(new java.awt.Color(255, 255, 255));
        Course_Name_Label.setText("Course Name :");
        Course_Name_Label.setToolTipText("Enter Course Code");
        getContentPane().add(Course_Name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, 40));

        Tutor_Name_jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Tutor_Name_jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        Tutor_Name_jLabel3.setText("Tutor Name :");
        Tutor_Name_jLabel3.setToolTipText("Enter Course Name");
        getContentPane().add(Tutor_Name_jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, 40));

        ttttime_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(ttttime_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 139, -1));

        Day_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Day_Label.setForeground(new java.awt.Color(255, 255, 255));
        Day_Label.setText("Date :");
        Day_Label.setToolTipText("EnterAppointment  Day");
        getContentPane().add(Day_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 190, 40));

        Time_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Time_Label.setForeground(new java.awt.Color(255, 255, 255));
        Time_Label.setText("Time :");
        Time_Label.setToolTipText("Enter appointment Time");
        getContentPane().add(Time_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 190, 30));

        Date_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Date_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Date_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(Date_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 460, 139, -1));

        CID_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        CID_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CID_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(CID_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 510, 139, -1));

        AddButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        AddButton1.setForeground(new java.awt.Color(45, 62, 94));
        AddButton1.setText("Add Data");
        AddButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(AddButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 590, 353, -1));

        DeleteButton2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        DeleteButton2.setForeground(new java.awt.Color(45, 62, 94));
        DeleteButton2.setText("Delete Data");
        DeleteButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(DeleteButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 590, 353, -1));

        Session_No_jLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Session_No_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        Session_No_jLabel.setText("Session No :");
        getContentPane().add(Session_No_jLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, 30));

        ChoosenTim_jTextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        ChoosenTim_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChoosenTim_jTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(ChoosenTim_jTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 139, -1));

        jPanel10.setBackground(new java.awt.Color(45, 62, 94));

        BackButton6.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        BackButton6.setForeground(new java.awt.Color(45, 62, 94));
        BackButton6.setText("Back");
        BackButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButton6ActionPerformed(evt);
            }
        });

        EXITButton4.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        EXITButton4.setForeground(new java.awt.Color(45, 62, 94));
        EXITButton4.setText("Exit");
        EXITButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EXITButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(BackButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(EXITButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BackButton6)
                    .addComponent(EXITButton4))
                .addContainerGap())
        );

        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 770, 290, 80));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        //Set data to thier textfield

        Connection con = null;
        try {
            con = getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PeerEducationTutor.class.getName()).log(Level.SEVERE, null, ex);
        }
         Statement st;
         DefaultTableModel TableModel1 = (DefaultTableModel) jTable1.getModel();
        
//Set data to text field when raw is selected

        
        int SesstionNumber =  Integer.valueOf(TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString());
        String PeerEduTutor= TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString();
        String CourseCode= TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString();
        String CourseName= TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString();
        String day= TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString();
        String time= TableModel1.getValueAt(jTable1.getSelectedRow(),0).toString();
     

        ttttime_TextField.setText(" " + SesstionNumber );
        Session_TextField.setText(PeerEduTutor);
        CID_TextField.setText(CourseCode);
        CoursNamee_TextField.setText(CourseName);
        Date_TextField.setText(day);
        Session_TextField.setText(time);
            
   
    }//GEN-LAST:event_jTable1MouseClicked

    private void Session_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Session_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Session_TextFieldActionPerformed

    private void Date_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Date_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Date_TextFieldActionPerformed

    private void CID_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CID_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CID_TextFieldActionPerformed

    private void AddButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButton1ActionPerformed


 
        // TODO add your handling code here:
//        if ( Session_TextField.getText() => "8" ) {
//            
//                    JOptionPane.showMessageDialog(this," Session Number Should Be Larger Than 8 ");
//        }
         if( Session_TextField.getText().equals("") ||
            CoursNamee_TextField.getText().equals("")||
            ttttime_TextField.getText().equals("")||
            Date_TextField.getText().equals("")||
            ChoosenTim_jTextField.getText().equals("")||
            CID_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please Enter All Data!");}
        
        else{
            String data[]={Session_TextField.getText(),CoursNamee_TextField.getText(),
                ttttime_TextField.getText(),ChoosenTim_jTextField.getText(),
                Date_TextField.getText(),CID_TextField.getText()
            };

            DefaultTableModel tblMpdel =(DefaultTableModel)jTable1.getModel();
            tblMpdel.addRow(data);
            
        
        Connection con = null;
        try {
            con = getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PeerEducationTutor.class.getName()).log(Level.SEVERE, null, ex);
        }
         Statement st;
         DefaultTableModel TableModel1 = (DefaultTableModel) jTable1.getModel();
             

      try {
                    st = con.createStatement();

                    for(int i = 0; i < TableModel1.getRowCount(); i++){

                        int SesstionNumber1 = Integer.valueOf(TableModel1.getValueAt(i, 0).toString());
                        String PeerEduTutor1 = TableModel1.getValueAt(i, 1).toString();
                        String CourseCode1 = TableModel1.getValueAt(i, 2).toString();
                        String CourseName1 = TableModel1.getValueAt(i, 3).toString();
                        String day1 = TableModel1.getValueAt(i, 4).toString();
                        String time1 = TableModel1.getValueAt(i, 5).toString();
                        
                        String sqlQuery1 = "INSERT INTO `peer_education_tutor`(`Session_No`, `Tutor_Name`, `Course_ID`, `Course_Name` , `ChoosenDay`, `ChoosenTime` ) "
                                + "VALUES ("+SesstionNumber1+",'"+PeerEduTutor1+"','"+CourseCode1+"','"+CourseName1+"' ,'"+day1+"','"+time1+"')";

                        st.addBatch(sqlQuery1);
                    }
                                   
                    
                    int[] rowsInserted = st.executeBatch();

            JOptionPane.showMessageDialog(this, "Add Added Successfully !");
            
            Refresh();
                    
         } catch (SQLException ex) {
                    Logger.getLogger(PeerEducationTutor.class.getName()).log(Level.SEVERE, null, ex);
                }
            
     
        }
    }//GEN-LAST:event_AddButton1ActionPerformed

    private void DeleteButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButton2ActionPerformed
        // TODO add your handling code here:

        //Get Jtable model first
        DefaultTableModel TableModel1= (DefaultTableModel) jTable1.getModel();

        // If one row is selected then delete
        if(jTable1.getSelectedRowCount()==1) {
            TableModel1.removeRow(jTable1.getSelectedRow());
            JOptionPane.showMessageDialog(this,"Delete Correctly!");
            Refresh();
        }

        //if table is empty then display message
        else if(jTable1.getRowCount()==0)
        JOptionPane.showMessageDialog(this,"There Is No Data To Delete! ");

        //if table is not empty but not selected any row
        else
        JOptionPane.showMessageDialog(this,"PLease Select One Single Row For Delete. ");
    }//GEN-LAST:event_DeleteButton2ActionPerformed

    private void ChoosenTim_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChoosenTim_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ChoosenTim_jTextFieldActionPerformed

    private void BackButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButton6ActionPerformed
        // TODO add your handling code here:
//        PeerEducationPage GoTo_PeerEducationPage= new PeerEducationPage();
//        GoTo_PeerEducationPage.show(); //Display  GetStarted here
//        dispose(); //Close Current GetStarted after click Home
    }//GEN-LAST:event_BackButton6ActionPerformed

    private void EXITButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EXITButton4ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_EXITButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PeerEducationTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PeerEducationTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PeerEducationTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PeerEducationTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PeerEducationTutor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton1;
    private javax.swing.JButton BackButton6;
    private javax.swing.JTextField CID_TextField;
    private javax.swing.JTextField ChoosenTim_jTextField;
    private javax.swing.JTextField CoursNamee_TextField;
    private javax.swing.JLabel Course_ID_jLabel;
    private javax.swing.JLabel Course_Name_Label;
    private javax.swing.JTextField Date_TextField;
    private javax.swing.JLabel Day_Label;
    private javax.swing.JButton DeleteButton2;
    private javax.swing.JButton EXITButton4;
    private javax.swing.JLabel Session_No_jLabel;
    private javax.swing.JTextField Session_TextField;
    private javax.swing.JLabel Time_Label;
    private javax.swing.JLabel Tutor_Name_jLabel3;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField ttttime_TextField;
    // End of variables declaration//GEN-END:variables


    public void Refresh() {
    
            Session_TextField.setText("");
            CoursNamee_TextField.setText("");
            ttttime_TextField.setText("");
            ChoosenTim_jTextField.setText("");
            Date_TextField.setText("");
            CID_TextField.setText("");
    
    }




}

