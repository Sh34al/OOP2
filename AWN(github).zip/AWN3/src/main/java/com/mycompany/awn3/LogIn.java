package com.mycompany.awn3;


import com.mycompany.awn3.GetStarted;
import com.mycompany.awn3.serviecesInterFace;
import com.mycompany.awn3.EmployeeInterfaces;
import com.mycompany.awn3.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class LogIn extends javax.swing.JFrame {

    /** Creates new form LogIn */
    
    
    //DBConnection con;
    public LogIn() {
        initComponents();
        
//        con = new DBConnection();
//        
//        if ( con == null ) {
//        
//            JOptionPane.showMessageDialog(this, "Database connection not available.", "Error" , JOptionPane.ERROR_MESSAGE );
//
//        }
//        else {
//        
//        
//        }
        
    }

 
    
    
    
    
   
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        LogIn_Button = new javax.swing.JButton();
        Textfield_UserName = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        StudentRidio = new javax.swing.JRadioButton();
        EmployeeRadio = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        Show_Hide_ToggleBut = new javax.swing.JToggleButton();
        Textfield_PassWord = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1370, 710));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1729, 935, -1, -1));

        LogIn_Button.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        LogIn_Button.setForeground(new java.awt.Color(45, 62, 94));
        LogIn_Button.setText("Log In");
        LogIn_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogIn_ButtonActionPerformed(evt);
            }
        });
        getContentPane().add(LogIn_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 500, 430, 80));

        Textfield_UserName.setBackground(new java.awt.Color(45, 62, 94));
        Textfield_UserName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Textfield_UserName.setForeground(new java.awt.Color(255, 255, 255));
        Textfield_UserName.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Textfield_UserName.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(255, 255, 255)));
        Textfield_UserName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Textfield_UserNameActionPerformed(evt);
            }
        });
        getContentPane().add(Textfield_UserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 260, 400, 70));

        jPanel2.setBackground(new java.awt.Color(45, 62, 94));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        StudentRidio.setBackground(new java.awt.Color(45, 62, 94));
        StudentRidio.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        StudentRidio.setForeground(new java.awt.Color(255, 255, 255));
        StudentRidio.setText("Student");
        StudentRidio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentRidioActionPerformed(evt);
            }
        });
        jPanel2.add(StudentRidio);

        EmployeeRadio.setBackground(new java.awt.Color(45, 62, 94));
        EmployeeRadio.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        EmployeeRadio.setForeground(new java.awt.Color(255, 255, 255));
        EmployeeRadio.setText("Employee");
        EmployeeRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmployeeRadioActionPerformed(evt);
            }
        });
        jPanel2.add(EmployeeRadio);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 410, 430, 80));

        jPanel3.setBackground(new java.awt.Color(45, 62, 94));
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 530, 120, -1));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jButton4.setForeground(new java.awt.Color(45, 62, 94));
        jButton4.setText("Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 600, -1, -1));

        Show_Hide_ToggleBut.setForeground(new java.awt.Color(46, 62, 93));
        Show_Hide_ToggleBut.setText("Show");
        Show_Hide_ToggleBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Show_Hide_ToggleButActionPerformed(evt);
            }
        });
        getContentPane().add(Show_Hide_ToggleBut, new org.netbeans.lib.awtextra.AbsoluteConstraints(1151, 350, 70, 50));

        Textfield_PassWord.setBackground(new java.awt.Color(45, 62, 94));
        Textfield_PassWord.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Textfield_PassWord.setForeground(new java.awt.Color(255, 255, 255));
        Textfield_PassWord.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Textfield_PassWord.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(255, 255, 255)));
        Textfield_PassWord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Textfield_PassWordActionPerformed(evt);
            }
        });
        getContentPane().add(Textfield_PassWord, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 340, 400, 70));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\AWNUPDATED2\\AWNUPDATED\\AWN2\\Loginnnnn.png")); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1450, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LogIn_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogIn_ButtonActionPerformed
        // TODO add your handling code here: //log in button
    
         
        String username = Textfield_UserName.getText () ; 
        String password = String.valueOf(Textfield_PassWord.getPassword());
        
//student 
if(StudentRidio.isSelected()) {
   
if (username.isEmpty () || password. isEmpty ()) 
{
JOptionPane.showMessageDialog(this, "Username / Password : should not be empty", "Error" , JOptionPane.ERROR_MESSAGE );
}

else{
            try {
                //start the login process as student
                userLoginStudent(username, password) ;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
            }

}
    
   }

else if (  EmployeeRadio.isSelected() ) {


if (username.isEmpty () || password. isEmpty ()) 
{
JOptionPane.showMessageDialog(this, "Username / Password : should not be empty", "Error" , JOptionPane.ERROR_MESSAGE );
}

else{
            try {
                //start the login process as employees
                userLoginEmployee(username, password) ;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
            }

}

} 
else
{
    JOptionPane.showMessageDialog(this,"Choose : Student / Employee.");
}
        
        

        
    }//GEN-LAST:event_LogIn_ButtonActionPerformed

    private void EmployeeRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmployeeRadioActionPerformed
        // TODO add your handling code here:
        if(EmployeeRadio.isSelected())
                StudentRidio.setSelected(false);
        
        
    }//GEN-LAST:event_EmployeeRadioActionPerformed

    private void Textfield_UserNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Textfield_UserNameActionPerformed

///Textfield_UserName=new JTextField("User Name",20);
//Textfield_UserName.setText("User Name");
//Textfield_UserName.setEditable(true);
//Textfield_UserName.setForeground(Color.white);

add(Textfield_UserName);
// TODO add your handling code here:
    }//GEN-LAST:event_Textfield_UserNameActionPerformed

    private void Textfield_PassWordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Textfield_PassWordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Textfield_PassWordActionPerformed

    private void StudentRidioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentRidioActionPerformed
        // TODO add your handling code here:
        if(StudentRidio.isSelected())
                EmployeeRadio.setSelected(false);
  
    }//GEN-LAST:event_StudentRidioActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         GetStarted GoTo_GetStarted= new GetStarted();
        GoTo_GetStarted.show(); //Display GetStarted here
        dispose(); //Close Current GetStarted after click Home
    }//GEN-LAST:event_jButton4ActionPerformed

    private void Show_Hide_ToggleButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Show_Hide_ToggleButActionPerformed
        // TODO add your handling code here:
        //togglebutt
        
        
        if(Show_Hide_ToggleBut.isSelected()) 
       {
         Textfield_PassWord.setEchoChar((char)0);
         Show_Hide_ToggleBut.setText("Hide");
       }
       else 
       {
           Textfield_PassWord.setEchoChar('\u25cf');
           
           Show_Hide_ToggleBut.setText("Show");}
        
    }//GEN-LAST:event_Show_Hide_ToggleButActionPerformed

    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LogIn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton EmployeeRadio;
    private javax.swing.JButton LogIn_Button;
    private javax.swing.JToggleButton Show_Hide_ToggleBut;
    private javax.swing.JRadioButton StudentRidio;
    private javax.swing.JPasswordField Textfield_PassWord;
    private javax.swing.JTextField Textfield_UserName;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables

    private void userLoginStudent(String username, String password) throws ClassNotFoundException {

Connection dbconn = DBConnection.getConnection();
if (dbconn != null) {

try
{
    
PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement(" Select * from Student WHERE Stu_ID = ? AND StdPassword = ? ");
st.setString (1, username) ;
st.setString (2, password) ;
ResultSet res = st.executeQuery();

if( res.next() ) {
    
    
 String username11 = res.getString("Stu_ID");

    serviecesInterFace serviecesInterFace= new serviecesInterFace();
    serviecesInterFace.show(); //Display  serviecesInterFace here
    dispose(); //Close Current serviecesInterFace after click log in

//JLabel display_user_account = new JLabel (username11);
//
//serviecesInterFace home = new serviecesInterFace();
//
//display_user_account.setBounds(1360, 25,150, 30);
//
//display_user_account.setForeground(Color.red);
//        
//home.add(display_user_account);
//
//home.setLayout(null);
//
//home.setSize( 1400, 1200 );
//
//home.setVisible(true);

    
}

else {
    System. out. println("Username : " + username);
    
    System. out. println("Password : " + password);
    
    JOptionPane.showMessageDialog(this,"Username / Password : incorrect .");
}

}
catch (SQLException ex)
{
         Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
}
}
else
{
    JOptionPane.showMessageDialog(this,"The connection not available.");
}

    }
    
    
    
  private void userLoginEmployee(String username, String password) throws ClassNotFoundException {

Connection dbconn = DBConnection.getConnection();
if (dbconn != null) {

try
{
    
PreparedStatement st = (PreparedStatement)
        dbconn.prepareStatement(" Select * from Employee WHERE Emp_ID = ? AND EMPPassword = ? ");
st.setString (1, username) ;
st.setString (2, password) ;
ResultSet res = st.executeQuery();

if( res.next() ) {
    
    
 String username11 = res.getString("Emp_ID");

    EmployeeInterfaces EmployeeInterfaces= new EmployeeInterfaces();
    EmployeeInterfaces.show(); //Display  EmployeeInterfaces here
    dispose(); //Close Current after click button

//JLabel display_user_account = new JLabel (username11);
//
//serviecesInterFace home = new serviecesInterFace();
//
//display_user_account.setBounds(1360, 25,150, 30);
//
//display_user_account.setForeground(Color.red);
//        
//home.add(display_user_account);
//
//home.setLayout(null);
//
//home.setSize( 1400, 1200 );
//
//home.setVisible(true);

    
}

else {
    System. out. println("Username : " + username);
    
    System. out. println("Password : " + password);
    
    JOptionPane.showMessageDialog(this,"Username / Password : incorrect .");
}

}
catch (SQLException ex)
{
         Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
}
}
else
{
    JOptionPane.showMessageDialog(this,"The connection not available.");
}

    }
    
    
    
    
}






