package com.mycompany.awn3;

import com.mycompany.awn3.PartTimeJobDetails;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author User
 */

public class Settings_PartTimeJob extends javax.swing.JFrame {

    /**
     * Creates new form Settings_PartTimeJob
     */
    public Settings_PartTimeJob() {
        initComponents();
        try {
            Show_PartTime_in_Table();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    
             // create a function to connect with mysql database
    public static Connection getConnection() throws ClassNotFoundException
            
            //CommunityPartnerShip() Class = new CommunityPartnerShip();
    {
        Connection con = null;
        
         try {

            //Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "Nn123456!!");
        } catch (SQLException ex) {

             System.out.println(ex.getMessage());

        }
        return con;
    }
    public ArrayList<PartTimeJobDetails> get_PT_List() throws ClassNotFoundException {
        
        
    ArrayList<PartTimeJobDetails> PT_List = new ArrayList<PartTimeJobDetails>();
     Connection connection = getConnection();
     
     String query = "SELECT * From Part_Job_Time";
     Statement st;
     ResultSet rs;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(query);
            PartTimeJobDetails parttimeJobDetails;
            
            while (rs.next()) {
                
//                Private int Job_ID;
//                Private String Job_Name; 
//                Private String Job_Place;
//                Private Date Start_From;
//                Private Date End_At;
//                Private  String Work_Hours; 
//                Private int Salary;
//                Private int Services_Num;
            
            parttimeJobDetails = new PartTimeJobDetails( 
                    rs.getInt("Job_ID") , 
                    rs.getString("Job_Name") , 
                    rs.getString("Job_Place") ,
                    rs.getDate("Start_From") ,
                    rs.getDate("End_At") ,
                    rs.getString("Work_Hours"),
                    rs.getInt("Salary"),
                    rs.getString("Services_Num"));
            PT_List.add(parttimeJobDetails);
            
            }//end of while

            
        } catch (SQLException ex) {
            Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
        }

    return PT_List;
    
    }
    
    
        //display data in table  
    public void Show_PartTime_in_Table() throws ClassNotFoundException {
    
        ArrayList<PartTimeJobDetails> ilst = get_PT_List();
        
        DefaultTableModel TableModel1 = (DefaultTableModel) jTable1.getModel();

    Object[] row = new Object[8];
    
    for(int i = 0; i < ilst.size(); i++){
        
//                Private int Job_ID;
//                Private String Job_Name; 
//                Private String Job_Place;
//                Private Date Start_From;
//                Private Date End_At;
//                Private  String Work_Hours; 
//                Private int Salary;
//                Private int Services_Num;
        
            row[0] = ilst.get(i).getJob_ID();
            row[1] = ilst.get(i).getJob_Name();
            row[2] = ilst.get(i).getJob_Place();
            row[3] = ilst.get(i).getStart_From();
            row[4] = ilst.get(i).getEnd_At();
            row[5] = ilst.get(i).getWork_Hours();
            row[6] = ilst.get(i).getSalary();
            row[7] = ilst.get(i).getServices_Num();

            
  TableModel1.addRow(row);
        
        
    }

    
    }
    
    
     //Exequte the SQL squery
    
    public void excecutSQLQuery( String query , String message ) throws ClassNotFoundException {
    
         Connection connection = getConnection();
         Statement st;
         
         

        try {
            st = connection.createStatement( );
            
            if ((st.executeUpdate(query)) == 1  ) {
              JOptionPane.showMessageDialog(this, " Date."+ message+"Successfuly !" ); 
            }
            else {
                          JOptionPane.showMessageDialog(this, " No Date."+ message ); 
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    
    
    
    
    
    

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Job_No_jLabel = new javax.swing.JLabel();
        JobID_TextField = new javax.swing.JTextField();
        Tutor_Name_jLabel3 = new javax.swing.JLabel();
        JobNamee_TextField = new javax.swing.JTextField();
        Course_ID_jLabel = new javax.swing.JLabel();
        StartFrom_TextField = new javax.swing.JTextField();
        Course_Name_Label = new javax.swing.JLabel();
        EndAt_jTextField = new javax.swing.JTextField();
        Day_Label = new javax.swing.JLabel();
        work_TextField = new javax.swing.JTextField();
        Time_Label = new javax.swing.JLabel();
        Slary_TextField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Service_Label1 = new javax.swing.JLabel();
        Service_TextField1 = new javax.swing.JTextField();
        Job_Place_jLabel4 = new javax.swing.JLabel();
        JobPlace_TextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        InsertButton = new javax.swing.JButton();
        UpdateButton1 = new javax.swing.JButton();
        DeleteButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Job_No_jLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Job_No_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        Job_No_jLabel.setText("Job ID :");
        getContentPane().add(Job_No_jLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, 30));

        JobID_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        JobID_TextField.setToolTipText("Enter Sesstion Number");
        JobID_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JobID_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(JobID_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 139, -1));

        Tutor_Name_jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Tutor_Name_jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        Tutor_Name_jLabel3.setText("Job Name :");
        Tutor_Name_jLabel3.setToolTipText("Enter Course Name");
        getContentPane().add(Tutor_Name_jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, -1, 40));

        JobNamee_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(JobNamee_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, 139, -1));

        Course_ID_jLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Course_ID_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        Course_ID_jLabel.setText("Start Date :");
        getContentPane().add(Course_ID_jLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 190, 40));

        StartFrom_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(StartFrom_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 139, -1));

        Course_Name_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Course_Name_Label.setForeground(new java.awt.Color(255, 255, 255));
        Course_Name_Label.setText("End Date :");
        Course_Name_Label.setToolTipText("Enter Course Code");
        getContentPane().add(Course_Name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, 40));

        EndAt_jTextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        EndAt_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EndAt_jTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(EndAt_jTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 470, 139, -1));

        Day_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Day_Label.setForeground(new java.awt.Color(255, 255, 255));
        Day_Label.setText("Work Hours :");
        Day_Label.setToolTipText("Should be Double");
        getContentPane().add(Day_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 190, 40));

        work_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        work_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                work_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(work_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 520, 139, -1));

        Time_Label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Time_Label.setForeground(new java.awt.Color(255, 255, 255));
        Time_Label.setText("Salary :");
        Time_Label.setToolTipText("Enter appointment Time");
        getContentPane().add(Time_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 580, 190, 30));

        Slary_TextField.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Slary_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Slary_TextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(Slary_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 580, 139, -1));

        jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jTable1.setFont(new java.awt.Font("Lucida Fax", 1, 16)); // NOI18N
        jTable1.setForeground(new java.awt.Color(46, 62, 93));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Job ID", "Job Name", "Job Place", "Start From", "End At", "Work Hours", "Salary", "Services_Num"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setAlignmentX(5.0F);
        jTable1.setAlignmentY(5.0F);
        jTable1.setPreferredSize(new java.awt.Dimension(2000, 2000));
        jTable1.setRowHeight(40);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 950, 330));

        Service_Label1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Service_Label1.setForeground(new java.awt.Color(255, 255, 255));
        Service_Label1.setText("Service No :");
        Service_Label1.setToolTipText("Enter appointment Time");
        getContentPane().add(Service_Label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 640, 190, 30));

        Service_TextField1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        Service_TextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Service_TextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(Service_TextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 640, 139, -1));

        Job_Place_jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Job_Place_jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        Job_Place_jLabel4.setText("Job Place :");
        Job_Place_jLabel4.setToolTipText("Enter Course Name");
        getContentPane().add(Job_Place_jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, 40));

        JobPlace_TextField1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(JobPlace_TextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 139, -1));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        InsertButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        InsertButton.setForeground(new java.awt.Color(45, 62, 94));
        InsertButton.setText("Insert Data");
        InsertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertButtonActionPerformed(evt);
            }
        });
        getContentPane().add(InsertButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 610, 210, -1));

        UpdateButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        UpdateButton1.setForeground(new java.awt.Color(45, 62, 94));
        UpdateButton1.setText("Update Data");
        UpdateButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(UpdateButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 610, 210, -1));

        DeleteButton3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        DeleteButton3.setForeground(new java.awt.Color(45, 62, 94));
        DeleteButton3.setText("Delete Data");
        DeleteButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(DeleteButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 610, 210, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JobID_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JobID_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JobID_TextFieldActionPerformed

    private void EndAt_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EndAt_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EndAt_jTextFieldActionPerformed

    private void work_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_work_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_work_TextFieldActionPerformed

    private void Slary_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Slary_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Slary_TextFieldActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        //Set data to thier textfield

       int i = jTable1.getSelectedRow();

        TableModel model = jTable1.getModel();

        JobID_TextField.setText(model.getValueAt(i, 0).toString());
        JobNamee_TextField.setText(model.getValueAt(i, 1).toString());
        JobPlace_TextField1.setText(model.getValueAt(i, 2).toString());
        StartFrom_TextField.setText(model.getValueAt(i, 3).toString());
        EndAt_jTextField.setText(model.getValueAt(i, 4).toString());
        work_TextField.setText(model.getValueAt(i, 5).toString());
        Slary_TextField.setText(model.getValueAt(i, 6).toString());
        Service_TextField1.setText(model.getValueAt(i, 7).toString());

//        JobID_TextField.setText( "" + Job_ID );
//        JobNamee_TextField.setText(Job_Name);
//        JobPlace_TextField1.setText(Job_Place);
//
//        StartFrom_TextField.setText(""+ Start_From);
//        EndAt_jTextField.setText(""+ End_At);
//
//        work_TextField.setText(Work_Hours);
//        Slary_TextField.setText(" " + Salary);
//        Service_TextField1.setText(ServiceNum);
        

        
        
        
    }//GEN-LAST:event_jTable1MouseClicked
       
    private void Service_TextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Service_TextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Service_TextField1ActionPerformed

    private void InsertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertButtonActionPerformed
        // TODO add your handling code here:
        
//                Private int Job_ID;
//                Private String Job_Name; 
//                Private String Job_Place;
//                Private Date Start_From;
//                Private Date End_At;
//                Private  String Work_Hours; 
//                Private int Salary;
//                Private int Services_Num;

        String query = "INSERT INTO `Part_Job_Time`("
                + "`Job_ID`, "
                + "`Job_Name`, "
                + "`Job_Place`, "
                + "`Start_From` ,"
                + " `End_At`, "
                + "`Work_Hours`  , "
                + "`Salary`  , "
                + "Services_Num ) "
                
//        JobID_TextField.setText( "" + Job_ID );
//        JobNamee_TextField.setText(Job_Name);
//        JobPlace_TextField1.setText(Job_Place);
//
//        StartFrom_TextField.setText(""+ Start_From);
//        EndAt_jTextField.setText(""+ End_At);
//
//        work_TextField.setText(Work_Hours);
//        Slary_TextField.setText(" " + Salary);
//        Service_TextField1.setText(ServiceNum);
                
                
                
        + "VALUES ("
                + ""+JobID_TextField.getText()+","
                + "'"+JobNamee_TextField.getText()+"',"
                + "'"+JobPlace_TextField1.getText()+"',"
                + "'"+StartFrom_TextField.getText()+"' ,"
                + "'"+EndAt_jTextField.getText()+"',"
                + "'"+work_TextField.getText()+"',"
                + "'"+Slary_TextField.getText()+"',"
                + "'"+ Service_TextField1.getText()+"' )";

        try {
            excecutSQLQuery( query ,"Data_Inserted");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_InsertButtonActionPerformed

    private void UpdateButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButton1ActionPerformed

        //        // TODO add your handling code here:
        //
        // TODO add your handling code here:

        if( JobID_TextField.getText().equals("") ||
            JobNamee_TextField.getText().equals("")||
            JobPlace_TextField1.getText().equals("")||
            StartFrom_TextField.getText().equals("")||
                
            EndAt_jTextField.getText().equals("") ||
             work_TextField.getText().equals("")||
            Slary_TextField.getText().equals("")||
            Service_TextField1.getText().equals("") )
        {
            JOptionPane.showMessageDialog(this, "Please Enter All Data!");}

        else{
            String data[]={JobID_TextField.getText(),JobNamee_TextField.getText(),JobPlace_TextField1.getText() ,
                StartFrom_TextField.getText(),EndAt_jTextField.getText(),
                work_TextField.getText(),Slary_TextField.getText(), Service_TextField1.getText()
            };

            DefaultTableModel tblMpdel =(DefaultTableModel)jTable1.getModel();
            tblMpdel.addRow(data);

            Connection con = null;
            try {
                con = getConnection();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
            }
            Statement st;
            DefaultTableModel TableModel1 = (DefaultTableModel) jTable1.getModel();

            try {
                st = con.createStatement();

                for(int i = 0; i < TableModel1.getRowCount(); i++){

                    int Job_ID = Integer.valueOf(TableModel1.getValueAt(i, 0).toString());
                    String Job_Name = TableModel1.getValueAt(i, 1).toString();
                    String Job_Place = TableModel1.getValueAt(i, 2).toString();
                    Date Start_From = Date.valueOf(TableModel1.getValueAt(i, 3).toString());
                    Date End_At = Date.valueOf(TableModel1.getValueAt(i, 4).toString());
                    String Work_Hours = TableModel1.getValueAt(i, 5).toString();
                    int Salary = Integer.valueOf(TableModel1.getValueAt(i, 6).toString());
                    String ServiceNum = TableModel1.getValueAt(i, 7).toString();


                    st.execute("UPDATE Part_Job_Time SET Job_Name ='" + JobNamee_TextField.getText() + "',Job_Place=" + JobPlace_TextField1.getText() + "',Start_From=" + StartFrom_TextField.getText() +  "',End_At=" + EndAt_jTextField.getText() +  "', Work_Hours=" +work_TextField.getText() +  "', Salary =" +Slary_TextField.getText() + "', Services_Num =" + Service_TextField1.getText() + " WHERE Job_ID=" + JobID_TextField.getText() + "");
                    JOptionPane.showMessageDialog(null, "Record is Updated...");

                    //st.addBatch(sqlQuery1);
                }

                //int[] rowsInserted = st.executeBatch();

                //JOptionPane.showMessageDialog(this, "Add Added Successfully !");

                Refresh();

            } catch (SQLException ex) {
                Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
            }

        
          }

    }//GEN-LAST:event_UpdateButton1ActionPerformed

    private void DeleteButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButton3ActionPerformed
        // TODO add your handling code here:

        String query = "DELETE FROM `Part_Job_Time` WHERE`Job_ID` = "+ JobID_TextField.getText();
        try {
            excecutSQLQuery( query ,"Data_Deleted");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Settings_PartTimeJob.class.getName()).log(Level.SEVERE, null, ex);
        }
        Refresh();

    }//GEN-LAST:event_DeleteButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Settings_PartTimeJob.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Settings_PartTimeJob.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Settings_PartTimeJob.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Settings_PartTimeJob.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Settings_PartTimeJob().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Course_ID_jLabel;
    private javax.swing.JLabel Course_Name_Label;
    private javax.swing.JLabel Day_Label;
    private javax.swing.JButton DeleteButton3;
    private javax.swing.JTextField EndAt_jTextField;
    private javax.swing.JButton InsertButton;
    private javax.swing.JTextField JobID_TextField;
    private javax.swing.JTextField JobNamee_TextField;
    private javax.swing.JTextField JobPlace_TextField1;
    private javax.swing.JLabel Job_No_jLabel;
    private javax.swing.JLabel Job_Place_jLabel4;
    private javax.swing.JLabel Service_Label1;
    private javax.swing.JTextField Service_TextField1;
    private javax.swing.JTextField Slary_TextField;
    private javax.swing.JTextField StartFrom_TextField;
    private javax.swing.JLabel Time_Label;
    private javax.swing.JLabel Tutor_Name_jLabel3;
    private javax.swing.JButton UpdateButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField work_TextField;
    // End of variables declaration//GEN-END:variables




    
        public void Refresh() {
    
            JobID_TextField.setText("");
            JobNamee_TextField.setText("");
            StartFrom_TextField.setText("");
            EndAt_jTextField.setText("");
            work_TextField.setText("");
            Slary_TextField.setText("");
    
    }





}
