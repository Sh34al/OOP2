package com.mycompany.awn3;



import java.sql.*;

public class DBConnection {
    
   
          // create a function to connect with mysql database
    public static Connection getConnection() throws ClassNotFoundException
            
    {
        Connection con = null;
        
         try {

             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "Nn123456!!");
        } catch (SQLException ex) {

             System.out.println(ex.getMessage());

        }
        return con;
    }  
    
}
