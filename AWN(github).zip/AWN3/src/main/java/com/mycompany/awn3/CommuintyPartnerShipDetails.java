/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.awn3;

import java.sql.Date;

/**
 *
 * @author zaina
 */

public class CommuintyPartnerShipDetails {
        
private int CP_ID ;
private String CP_Name;
private String CP_type;
private String CP_Titlle;
private double CP_Price;
private Date CP_date;
private String CP_location;
private int Services_Num;

    public CommuintyPartnerShipDetails(int CP_ID, String CP_Name, String CP_type, String CP_Titlle, double CP_Price, Date CP_date, String CP_location, int Services_Num) {
        this.CP_ID = CP_ID;
        this.CP_Name = CP_Name;
        this.CP_type = CP_type;
        this.CP_Titlle = CP_Titlle;
        this.CP_Price = CP_Price;
        this.CP_date = CP_date;
        this.CP_location = CP_location;
        this.Services_Num = Services_Num;
    }

    public int getCP_ID() {
        return CP_ID;
    }

    public void setCP_ID(int CP_ID) {
        this.CP_ID = CP_ID;
    }

    public String getCP_Name() {
        return CP_Name;
    }

    public void setCP_Name(String CP_Name) {
        this.CP_Name = CP_Name;
    }

    public String getCP_type() {
        return CP_type;
    }

    public void setCP_type(String CP_type) {
        this.CP_type = CP_type;
    }

    public String getCP_Titlle() {
        return CP_Titlle;
    }

    public void setCP_Titlle(String CP_Titlle) {
        this.CP_Titlle = CP_Titlle;
    }

    public double getCP_Price() {
        return CP_Price;
    }

    public void setCP_Price(double CP_Price) {
        this.CP_Price = CP_Price;
    }

    public Date getCP_date() {
        return CP_date;
    }

    public void setCP_date(Date CP_date) {
        this.CP_date = CP_date;
    }

    public String getCP_location() {
        return CP_location;
    }

    public void setCP_location(String CP_location) {
        this.CP_location = CP_location;
    }

    public int getServices_Num() {
        return Services_Num;
    }

    public void setServices_Num(int Services_Num) {
        this.Services_Num = Services_Num;
    }



       

}
