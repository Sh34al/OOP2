/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.awn3;

import java.sql.Date;

/**
 *
 * @author zaina
 */
public class EntertainmentDetails {
    
    
   
private String Trip_Num ;
private String Trip_Name;
private Date Trip_Date;
private String Trip_Place;
private double Trip_Price;
private String Services_Num;

    public EntertainmentDetails(String Trip_Num, String Trip_Name, Date Trip_Date, String Trip_Place, double Trip_Price, String Services_Num) {
        this.Trip_Num = Trip_Num;
        this.Trip_Name = Trip_Name;
        this.Trip_Date = Trip_Date;
        this.Trip_Place = Trip_Place;
        this.Trip_Price = Trip_Price;
        this.Services_Num = Services_Num;
    }

    public String getTrip_Num() {
        return Trip_Num;
    }

    public void setTrip_Num(String Trip_Num) {
        this.Trip_Num = Trip_Num;
    }

    public String getTrip_Name() {
        return Trip_Name;
    }

    public void setTrip_Name(String Trip_Name) {
        this.Trip_Name = Trip_Name;
    }

    public Date getTrip_Date() {
        return Trip_Date;
    }

    public void setTrip_Date(Date Trip_Date) {
        this.Trip_Date = Trip_Date;
    }

    public String getTrip_Place() {
        return Trip_Place;
    }

    public void setTrip_Place(String Trip_Place) {
        this.Trip_Place = Trip_Place;
    }

    public double getTrip_Price() {
        return Trip_Price;
    }

    public void setTrip_Price(double Trip_Price) {
        this.Trip_Price = Trip_Price;
    }

    public String getServices_Num() {
        return Services_Num;
    }

    public void setServices_Num(String Services_Num) {
        this.Services_Num = Services_Num;
    }




    

}
