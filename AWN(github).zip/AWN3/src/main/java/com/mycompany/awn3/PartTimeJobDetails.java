package com.mycompany.awn3;

import java.sql.Date;


public class PartTimeJobDetails {
    
 private int Job_ID;
 private String Job_Name; 
 private String Job_Place;
 private Date Start_From;
 private Date End_At;
 private  String Work_Hours; 
 private int Salary;
 private String Services_Num;

    public PartTimeJobDetails(int Job_ID, String Job_Name, String Job_Place, Date Start_From, Date End_At, String Work_Hours, int Salary, String Services_Num) {
        this.Job_ID = Job_ID;
        this.Job_Name = Job_Name;
        this.Job_Place = Job_Place;
        this.Start_From = Start_From;
        this.End_At = End_At;
        this.Work_Hours = Work_Hours;
        this.Salary = Salary;
        this.Services_Num = Services_Num;
    }

    public int getJob_ID() {
        return Job_ID;
    }

    public void setJob_ID(int Job_ID) {
        this.Job_ID = Job_ID;
    }

    public String getJob_Name() {
        return Job_Name;
    }

    public void setJob_Name(String Job_Name) {
        this.Job_Name = Job_Name;
    }

    public String getJob_Place() {
        return Job_Place;
    }

    public void setJob_Place(String Job_Place) {
        this.Job_Place = Job_Place;
    }

    public Date getStart_From() {
        return Start_From;
    }

    public void setStart_From(Date Start_From) {
        this.Start_From = Start_From;
    }

    public Date getEnd_At() {
        return End_At;
    }

    public void setEnd_At(Date End_At) {
        this.End_At = End_At;
    }

    public String getWork_Hours() {
        return Work_Hours;
    }

    public void setWork_Hours(String Work_Hours) {
        this.Work_Hours = Work_Hours;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public String getServices_Num() {
        return Services_Num;
    }

    public void setServices_Num(String Services_Num) {
        this.Services_Num = Services_Num;
    }
 

  
    
    
    
    
    
}
