/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.awn3;

import java.sql.Date;


public class PeerEducationDetails {
    
    
    
    private int id;
    private String name;
    private String Course_ID;
    private String  Course_Name;
    private Date ChoosenDay;
    private String  ChoosenTime;
    private int  ServicesNum;

    public PeerEducationDetails(int id, String name, String Course_ID, String Course_Name, Date ChoosenDay, String ChoosenTime, int ServicesNum) {
        this.id = id;
        this.name = name;
        this.Course_ID = Course_ID;
        this.Course_Name = Course_Name;
        this.ChoosenDay = ChoosenDay;
        this.ChoosenTime = ChoosenTime;
        this.ServicesNum = ServicesNum;
    }

    public String getCourse_ID() {
        return Course_ID;
    }

    public void setCourse_ID(String Course_ID) {
        this.Course_ID = Course_ID;
    }

    public String getCourse_Name() {
        return Course_Name;
    }

    public void setCourse_Name(String Course_Name) {
        this.Course_Name = Course_Name;
    }

    public Date getChoosenDay() {
        return ChoosenDay;
    }

    public void setChoosenDay(Date ChoosenDay) {
        this.ChoosenDay = ChoosenDay;
    }

    public String getChoosenTime() {
        return ChoosenTime;
    }

    public void setChoosenTime(String ChoosenTime) {
        this.ChoosenTime = ChoosenTime;
    }

    public int getServicesNum() {
        return ServicesNum;
    }

    public void setServicesNum(int ServicesNum) {
        this.ServicesNum = ServicesNum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
